package fsutil

import (
	"archive/zip"
	"bytes"
	"fmt"
	"io"
	"io/fs"
	"os"
	"path/filepath"
	"strings"
)

func OpenZip(path string) (*zip.Reader, error) {
	buf, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}

	return zip.NewReader(bytes.NewReader(buf), int64(len(buf)))
}

func CreateZip(path string) (*os.File, *zip.Writer, error) {
	file, err := os.Create(path)
	if err != nil {
		return nil, nil, err
	}

	return file, zip.NewWriter(file), nil
}

// FindDirectory finds a directory in a fs.FS.
func FindDirectory(f fs.FS, name string) (dirPath string, found bool) {
	walkDirFunc := func(path string, d fs.DirEntry, err error) error {
		if d.Name() == name && d.IsDir() {
			dirPath = path
			found = true
		}
		return nil
	}

	_ = fs.WalkDir(f, ".", walkDirFunc)
	return
}

func Unzip(src, dest string) error {
	r, err := zip.OpenReader(src)
	if err != nil {
		return err
	}
	defer func() {
		if err := r.Close(); err != nil {
			panic(err)
		}
	}()

	os.MkdirAll(dest, 0755)

	// Closure to address file descriptors issue with all the deferred .Close() methods
	extractAndWriteFile := func(f *zip.File) error {
		rc, err := f.Open()
		if err != nil {
			return err
		}
		defer func() {
			if err := rc.Close(); err != nil {
				panic(err)
			}
		}()

		path := filepath.Join(dest, f.Name)

		// Check for ZipSlip (Directory traversal)
		if !strings.HasPrefix(path, filepath.Clean(dest)+string(os.PathSeparator)) {
			return fmt.Errorf("illegal file path: %s", path)
		}

		if f.FileInfo().IsDir() {
			os.MkdirAll(path, f.Mode())
		} else {
			os.MkdirAll(filepath.Dir(path), f.Mode())
			f, err := os.OpenFile(path, os.O_WRONLY|os.O_CREATE|os.O_TRUNC, f.Mode())
			if err != nil {
				return err
			}
			defer func() {
				if err := f.Close(); err != nil {
					panic(err)
				}
			}()

			_, err = io.Copy(f, rc)
			if err != nil {
				return err
			}
		}
		return nil
	}

	for _, f := range r.File {
		err := extractAndWriteFile(f)
		if err != nil {
			return err
		}
	}

	return nil
}
